# MERN Task Manager

A minimal MERN stack task manager with user registration/login (JWT) and task CRUD.

## Quick Start
### 1) Server
```bash
cd server
cp .env.sample .env  # set MONGO_URI and JWT_SECRET
npm install
npm run dev
```

### 2) Client
```bash
cd client
npm install
npm run dev
```

Open http://localhost:5173
