import express from 'express';
import Task from '../models/Task.js';
import { authRequired } from '../middleware/auth.js';

const router = express.Router();

// All routes require auth
router.use(authRequired);

// Get tasks for user
router.get('/', async (req, res) => {
  const tasks = await Task.find({ user: req.user.id }).sort({ createdAt: -1 });
  res.json({ tasks });
});

// Create task
router.post('/', async (req, res) => {
  const { title, description = '', status = 'todo', dueDate = null } = req.body;
  if (!title) return res.status(400).json({ message: 'Title is required' });
  const task = await Task.create({ user: req.user.id, title, description, status, dueDate });
  res.status(201).json({ task });
});

// Update task
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const updates = (({ title, description, status, dueDate }) => ({ title, description, status, dueDate }))(req.body);
  const task = await Task.findOneAndUpdate({ _id: id, user: req.user.id }, updates, { new: true });
  if (!task) return res.status(404).json({ message: 'Task not found' });
  res.json({ task });
});

// Delete task
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  const task = await Task.findOneAndDelete({ _id: id, user: req.user.id });
  if (!task) return res.status(404).json({ message: 'Task not found' });
  res.json({ message: 'Task deleted' });
});

export default router;
