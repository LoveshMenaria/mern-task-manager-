# Task Manager API (Server)

## Setup
1. Copy `.env.sample` to `.env` and set values.
2. Install deps: `npm install`
3. Run dev: `npm run dev` (requires MongoDB running)

### Endpoints
- `POST /api/auth/register` { name, email, password }
- `POST /api/auth/login` { email, password } -> { token }
- `GET /api/auth/me` (Bearer token)

- `GET /api/tasks` (Bearer)
- `POST /api/tasks` (Bearer) { title, description?, status?, dueDate? }
- `PUT /api/tasks/:id` (Bearer) { title?, description?, status?, dueDate? }
- `DELETE /api/tasks/:id` (Bearer)
