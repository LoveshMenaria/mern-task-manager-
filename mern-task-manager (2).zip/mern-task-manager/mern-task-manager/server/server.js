import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cors from "cors";
import cookieParser from "cookie-parser";

// import routes
import authRoutes from "./src/routes/auth.js";
import taskRoutes from "./src/routes/tasks.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI;

// Middleware
app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:5173" }));
app.use(express.json());
app.use(cookieParser());

// Test route
app.get("/", (req, res) => {
  res.json({ message: "Task Manager API is running" });
});

// Mount routes
app.use("/api/auth", authRoutes);
app.use("/api/tasks", taskRoutes);

// MongoDB connection + server start
mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log("✅ MongoDB connected");
    app.listen(PORT, () =>
      console.log(`🚀 Server running on http://localhost:${PORT}`)
    );
  })
  .catch((err) => {
    console.error("❌ MongoDB connection error:", err.message);
    process.exit(1);
  });






  // import express from 'express';
  // import mongoose from 'mongoose';
  // import dotenv from 'dotenv';
  // import cors from 'cors';
  // import cookieParser from 'cookie-parser';
  // import authRoutes from './src/routes/auth.js';
  // import taskRoutes from './src/routes/tasks.js';

  // dotenv.config();
  // const app = express();

  // const PORT = process.env.PORT || 5000;
  // const MONGO_URI = process.env.MONGO_URI;

  // // Middleware
  // app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
  // app.use(express.json());
  // app.use(cookieParser());

  // app.get('/', (req, res) => {
  //   res.json({ message: 'Task Manager API is running' });
  // });

  // // Routes
  // app.use('/api/auth', authRoutes);
  // app.use('/api/tasks', taskRoutes);

  // // DB + Server
  // mongoose.connect(MONGO_URI).then(() => {
  //   console.log('MongoDB connected');
  //   app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
  // }).catch(err => {
  //   console.error('MongoDB connection error:', err.message);
  //   process.exit(1);
  // });
