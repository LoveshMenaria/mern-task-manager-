# Task Manager Client (React + Vite)

## Setup
1. Install deps: `npm install`
2. Run dev: `npm run dev` (proxies `/api` calls to `http://localhost:5000`)

### Pages
- `/login` Login
- `/register` Create account
- `/` Protected task list & CRUD
