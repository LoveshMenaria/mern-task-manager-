//1

// import React from 'react'
// import { Routes, Route, Navigate, Link } from 'react-router-dom'
// import TaskList from './components/TaskList.jsx'
// import ProtectedRoute from './components/ProtectedRoute.jsx'


// function App() {
//   return (
//     <div style={{ maxWidth: 800, margin: '0 auto', padding: 16 }}>
//       <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//         <h1 style={{marginLeft:300}}>Task Manager</h1>
//         <nav style={{justifyContent:'space-evenly',backgroundColor:'crimson'}}>
//           <Link to="/" style={{ marginRight:40,textDecoration:'none',fontWeight:'bold'}}>Home</Link>
//            <Link onClick={{}} style={{ marginRight:40,textDecoration:'none',fontWeight:'bold'}}>My Task</Link>

//           <button onClick={() => { localStorage.removeItem('token'); window.location.href='/login'; }} style={{backgroundColor:'crimson',color:'white'}}>Logout</button>
         
//         </nav>
//       </header>
//       <Routes>
//         <Route path="/" element={<ProtectedRoute><TaskList/></ProtectedRoute>} />
//         <Route path="*" element={<Navigate to="/" />} />
//       </Routes>
//     </div>
//   )
// }
// export default App

//2
// import React, { useState } from 'react'
// import { Routes, Route, Navigate, Link } from 'react-router-dom'
// import TaskList from './components/TaskList.jsx'
// import ProtectedRoute from './components/ProtectedRoute.jsx'

// function App() {
//   const [showTasks, setShowTasks] = useState(false) // ✅ State for task list visibility

//   return (
//     <div style={{ maxWidth: 800, margin: '0 auto', padding: 16 }}>
//       <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//         <h1 style={{ marginLeft: 300 }}>Task Manager</h1>
//         <nav style={{
//           display: 'flex',
//           alignItems: 'center',
//           backgroundColor: 'crimson',
//           padding: '0.5rem 1rem',
//           borderRadius: 8
//         }}>
//           {/* Home Link */}
//           <Link to="/" style={{ marginRight: 40, textDecoration: 'none', fontWeight: 'bold', color: 'white' }}>
//             Home
//           </Link>

//           {/* ✅ My Task Button */}
//           <button
//             onClick={() => setShowTasks(prev => !prev)}
//             style={{
//               marginRight: 40,
//               fontWeight: 'bold',
//               background: 'transparent',
//               border: 'none',
//               cursor: 'pointer',
//               color: 'white'
//             }}
//           >
//             {showTasks ? 'Hide Tasks' : 'My Tasks'}
//           </button>

//           {/* Logout Button */}
//           <button
//             onClick={() => {
//               localStorage.removeItem('token')
//               window.location.href = '/login'
//             }}
//             style={{ backgroundColor: 'crimson', color: 'white', border: 'none', cursor: 'pointer' }}
//           >
//             Logout
//           </button>
//         </nav>
//       </header>

//       {/* Pass props to TaskList */}
//       <Routes>
//         <Route
//           path="/"
//           element={
//             <ProtectedRoute>
//               <TaskList showTasks={showTasks} />
//             </ProtectedRoute>
//           }
//         />
//         <Route path="*" element={<Navigate to="/" />} />
//       </Routes>
//     </div>
//   )
// }

// export default App


// 3

import React, { useState } from 'react'
import { Routes, Route, Navigate, Link } from 'react-router-dom'
import TaskList from './components/TaskList.jsx'
import ProtectedRoute from './components/ProtectedRoute.jsx'

function App() {
  const [view, setView] = useState('home') // home = add task form, tasks = view tasks

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: 16 }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1 style={{ marginLeft: 300 }}>Task Manager</h1>
        <nav style={{
          display: 'flex',
          alignItems: 'center',
          backgroundColor: 'crimson',
          padding: '0.5rem 1rem',
          borderRadius: 8
        }}>
          {/* ✅ Home Link (shows Add Task form) */}
          <Link
            to="/"
            style={{ marginRight: 40, textDecoration: 'none', fontWeight: 'bold', color: 'white' }}
            onClick={() => setView('home')}
          >
            Home
          </Link>

          {/* ✅ My Tasks Link (shows only task list) */}
          <button
            onClick={() => setView('tasks')}
            style={{
              marginRight: 40,
              fontWeight: 'bold',
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              color: 'white'
            }}
          >
            My Tasks
          </button>

          {/* Logout */}
          <button
            onClick={() => {
              localStorage.removeItem('token')
              window.location.href = '/login'
            }}
            style={{ backgroundColor: 'crimson', color: 'white', border: 'none', cursor: 'pointer' }}
          >
            Logout
          </button>
        </nav>
      </header>

      <Routes>
        <Route
          path="/"
          element={
            <ProtectedRoute>
              <TaskList view={view} />
            </ProtectedRoute>
          }
        />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </div>
  )
}

export default App



