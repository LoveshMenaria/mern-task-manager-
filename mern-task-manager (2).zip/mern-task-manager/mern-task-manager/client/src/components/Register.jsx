import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios'
import './Register.css'

export default function Register() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')
  const navigate = useNavigate()

  const submit = async (e) => {
    e.preventDefault()
    setError(''); setMessage('')
    try {
      await axios.post('/api/auth/register', { name, email, password })
      setMessage('Registered! You can now login.')
      setTimeout(()=>navigate('/login'), 500)
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed')
    }
  }


   return (
    <div className="register-container">
      <h2>Register</h2>
      <form onSubmit={submit} className="register-form">
        <div className="form-group">
          <label>Name</label>
          <input 
            value={name} 
            onChange={e => setName(e.target.value)} 
            type="text" 
            required 
          />
        </div>
        <div className="form-group">
          <label>Email</label>
          <input 
            value={email} 
            onChange={e => setEmail(e.target.value)} 
            type="email" 
            required 
          />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input 
            value={password} 
            onChange={e => setPassword(e.target.value)} 
            type="password" 
            required 
          />
        </div>
        {error && <p className="error">{error}</p>}
        {message && <p className="success">{message}</p>}
        <button type="submit" className="btn">Create Account</button>
      </form>
      <p className="login-link">
        Already have an account? <Link to="/login">Login</Link>
      </p>
    </div>
  )

  
  

  // return (
  //   <div style={{ maxWidth: 420, margin: '40px auto' }}>
  //     <h2>Register</h2>
  //     <form onSubmit={submit}>
  //       <div>
  //         <label>Name</label>
  //         <input value={name} onChange={e=>setName(e.target.value)} required />
  //       </div>
  //       <div>
  //         <label>Email</label>
  //         <input value={email} onChange={e=>setEmail(e.target.value)} type="email" required />
  //       </div>
  //       <div>
  //         <label>Password</label>
  //         <input value={password} onChange={e=>setPassword(e.target.value)} type="password" required />
  //       </div>
  //       {error && <p style={{ color: 'red' }}>{error}</p>}
  //       {message && <p style={{ color: 'green' }}>{message}</p>}
  //       <button type="submit">Create Account</button>
  //     </form>
  //     <p>Already have an account? <Link to="/login">Login</Link></p>
  //   </div>
  // )

  


}
