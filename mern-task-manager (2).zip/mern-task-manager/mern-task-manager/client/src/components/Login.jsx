import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios'
import './Login.css'






export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    try {
      const { data } = await axios.post('/api/auth/login', { email, password })
      localStorage.setItem('token', data.token)
      navigate('/')
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed')
    }
  }

  // return (
  //   <div style={{ maxWidth: 420, margin: '40px auto' }}>
  //     <h2>Login</h2>
  //     <form onSubmit={submit}>
  //       <div>
  //         <label>Email</label>
  //         <input value={email} onChange={e=>setEmail(e.target.value)} type="email" required />
  //       </div>
  //       <div>
  //         <label>Password</label>
  //         <input value={password} onChange={e=>setPassword(e.target.value)} type="password" required />
  //       </div>
  //       {error && <p style={{ color: 'red' }}>{error}</p>}
  //       <button type="submit">Login</button>
  //     </form>
  //     <p>Don&apos;t have an account? <Link to="/register">Register</Link></p>
  //   </div>
  // )

   return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={submit} className="login-form">
        <div className="form-group">
          <label>Email</label>
          <input 
            value={email} 
            onChange={e=>setEmail(e.target.value)} 
            type="email" 
            required 
          />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input 
            value={password} 
            onChange={e=>setPassword(e.target.value)} 
            type="password" 
            required 
          />
        </div>
        {error && <p className="error">{error}</p>}
        <button type="submit" className="btn">Login</button>
      </form>
      <p className="register-link">
        Don&apos;t have an account? <Link to="/register">Register</Link>
      </p>
    </div>
  )
}


