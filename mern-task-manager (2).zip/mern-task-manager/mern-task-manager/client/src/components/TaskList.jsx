
//1

// import React, { useEffect, useState } from 'react'
// import api from '../api'
// import './TaskList.css'


// export default function TaskList() {
//   const [tasks, setTasks] = useState([])
//   const [form, setForm] = useState({ title: '', description: '', status: 'todo', dueDate: '' })
//   const [editingId, setEditingId] = useState(null)
//   const [error, setError] = useState('')

//   const load = async () => {
//     try {
//       const { data } = await api.get('/tasks')
//       setTasks(data.tasks)
//     } catch (err) {
//       setError(err.response?.data?.message || 'Failed to load tasks')
//     }
//   }
//   useEffect(()=>{ load() }, [])

//   const submit = async (e) => {
//     e.preventDefault()
//     setError('')
//     try {
//       if (editingId) {
//         const { data } = await api.put(`/tasks/${editingId}`, payloadFromForm(form))
//         setTasks(tasks.map(t => t._id === editingId ? data.task : t))
//         setEditingId(null)
//       } else {
//         const { data } = await api.post('/tasks', payloadFromForm(form))
//         setTasks([data.task, ...tasks])
//       }
//       setForm({ title: '', description: '', status: 'todo', dueDate: '' })
//     } catch (err) {
//       setError(err.response?.data?.message || 'Save failed')
//     }
//   }

//   const edit = (t) => {
//     setEditingId(t._id)
//     setForm({
//       title: t.title,
//       description: t.description || '',
//       status: t.status,
//       dueDate: t.dueDate ? new Date(t.dueDate).toISOString().slice(0,10) : ''
//     })
//     window.scrollTo({ top: 0, behavior: 'smooth' })
//   }

//   const del = async (id) => {
//     if (!confirm('Delete this task?')) return
//     await api.delete(`/tasks/${id}`)
//     setTasks(tasks.filter(t => t._id !== id))
//   }

//     return (
//     <div className="task-container">
//       <h2 className="task-header">{editingId ? 'Edit Task' : 'New Task'}</h2>

//       <form className="task-form" onSubmit={submit}>
//         <input
//           className="task-input"
//           placeholder="Title"
//           value={form.title}
//           onChange={e => setForm({ ...form, title: e.target.value })}
//           required
//         />
//         <textarea
//           className="task-textarea"
//           placeholder="Description"
//           value={form.description}
//           onChange={e => setForm({ ...form, description: e.target.value })}
//         />
//         <select
//           className="task-select"
//           value={form.status}
//           onChange={e => setForm({ ...form, status: e.target.value })}
//         >
//           <option value="todo">To Do</option>
//           <option value="in-progress">In Progress</option>
//           <option value="done">Done</option>
//         </select>
//         <label className="task-label">
//           Due date:
//           <input
//             className="task-date"
//             type="date"
//             value={form.dueDate}
//             onChange={e => setForm({ ...form, dueDate: e.target.value })}
//           />
//         </label>
//         <div className="task-btn-group">
//           <button type="submit" className="btn btn-primary">
//             {editingId ? 'Update' : 'Create'}
//           </button>
//           {editingId && (
//             <button
//               type="button"
//               className="btn btn-secondary"
//               onClick={() => {
//                 setEditingId(null)
//                 setForm({ title: '', description: '', status: 'todo', dueDate: '' })
//               }}
//             >
//               Cancel
//             </button>
//           )}
//         </div>
//         {error && <p className="error-text">{error}</p>}
//       </form>

//       <h3 className="task-header">Your Tasks</h3>
//       {!tasks.length && <p className="empty-text">No tasks yet.</p>}

//       <ul className="task-list">
//         {tasks.map(t => (
//           <li key={t._id} className="task-card">
//             <div className="task-top">
//               <strong>{t.title}</strong>
//               <span className={`status-badge ${t.status}`}>{t.status}</span>
//             </div>
//             {t.description && <p>{t.description}</p>}
//             {t.dueDate && <p>Due: {new Date(t.dueDate).toLocaleDateString()}</p>}
//             <div className="task-actions">
//               <button className="btn btn-small btn-primary" onClick={() => edit(t)}>Edit</button>
//               <button className="btn btn-small btn-danger" onClick={() => del(t._id)}>Delete</button>
//             </div>
//           </li>
//         ))}
//       </ul>
//     </div>
//   )
// }



// function payloadFromForm(form) {
//   const payload = { title: form.title, description: form.description, status: form.status }
//   if (form.dueDate) payload.dueDate = new Date(form.dueDate).toISOString()
//   return payload
// }





//2
// import React, { useEffect, useState } from 'react'
// import api from '../api'
// import './TaskList.css'

// export default function TaskList({ showTasks }) {  // ✅ use prop instead of local state
//   const [tasks, setTasks] = useState([])
//   const [form, setForm] = useState({ title: '', description: '', status: 'todo', dueDate: '' })
//   const [editingId, setEditingId] = useState(null)
//   const [error, setError] = useState('')

//   const load = async () => {
//     try {
//       const { data } = await api.get('/tasks')
//       setTasks(data.tasks)
//     } catch (err) {
//       setError(err.response?.data?.message || 'Failed to load tasks')
//     }
//   }

//   useEffect(() => { load() }, [])

//   const submit = async (e) => {
//     e.preventDefault()
//     setError('')
//     try {
//       if (editingId) {
//         const { data } = await api.put(`/tasks/${editingId}`, payloadFromForm(form))
//         setTasks(tasks.map(t => t._id === editingId ? data.task : t))
//         setEditingId(null)
//       } else {
//         const { data } = await api.post('/tasks', payloadFromForm(form))
//         setTasks([data.task, ...tasks])
//       }
//       setForm({ title: '', description: '', status: 'todo', dueDate: '' })
//     } catch (err) {
//       setError(err.response?.data?.message || 'Save failed')
//     }
//   }

//   const edit = (t) => {
//     setEditingId(t._id)
//     setForm({
//       title: t.title,
//       description: t.description || '',
//       status: t.status,
//       dueDate: t.dueDate ? new Date(t.dueDate).toISOString().slice(0, 10) : ''
//     })
//     window.scrollTo({ top: 0, behavior: 'smooth' })
//   }

//   const del = async (id) => {
//     if (!window.confirm('Delete this task?')) return
//     await api.delete(`/tasks/${id}`)
//     setTasks(tasks.filter(t => t._id !== id))
//   }

//   return (
//     <div className="task-container">
//       <h2 className="task-header">{editingId ? 'Edit Task' : 'New Task'}</h2>

//       {/* Form */}
//       <form className="task-form" onSubmit={submit}>
//         <input
//           className="task-input"
//           placeholder="Title"
//           value={form.title}
//           onChange={e => setForm({ ...form, title: e.target.value })}
//           required
//         />
//         <textarea
//           className="task-textarea"
//           placeholder="Description"
//           value={form.description}
//           onChange={e => setForm({ ...form, description: e.target.value })}
//         />
//         <select
//           className="task-select"
//           value={form.status}
//           onChange={e => setForm({ ...form, status: e.target.value })}
//         >
//           <option value="todo">To Do</option>
//           <option value="in-progress">In Progress</option>
//           <option value="done">Done</option>
//         </select>
//         <label className="task-label">
//           Due date:
//           <input
//             className="task-date"
//             type="date"
//             value={form.dueDate}
//             onChange={e => setForm({ ...form, dueDate: e.target.value })}
//           />
//         </label>
//         <div className="task-btn-group">
//           <button type="submit" className="btn btn-primary">
//             {editingId ? 'Update' : 'Create'}
//           </button>
//           {editingId && (
//             <button
//               type="button"
//               className="btn btn-secondary"
//               onClick={() => {
//                 setEditingId(null)
//                 setForm({ title: '', description: '', status: 'todo', dueDate: '' })
//               }}
//             >
//               Cancel
//             </button>
//           )}
//         </div>
//         {error && <p className="error-text">{error}</p>}
//       </form>

//       {/* ✅ Show Tasks if true */}
//       {showTasks && (
//         <>
//           <h3 className="task-header">Your Tasks</h3>
//           {!tasks.length && <p className="empty-text">No tasks yet.</p>}
//           <ul className="task-list">
//             {tasks.map(t => (
//               <li key={t._id} className="task-card">
//                 <div className="task-top">
//                   <strong>{t.title}</strong>
//                   <span className={`status-badge ${t.status}`}>{t.status}</span>
//                 </div>
//                 {t.description && <p>{t.description}</p>}
//                 {t.dueDate && <p>Due: {new Date(t.dueDate).toLocaleDateString()}</p>}
//                 <div className="task-actions">
//                   <button className="btn btn-small btn-primary" onClick={() => edit(t)}>Edit</button>
//                   <button className="btn btn-small btn-danger" onClick={() => del(t._id)}>Delete</button>
//                 </div>
//               </li>
//             ))}
//           </ul>
//         </>
//       )}
//     </div>
//   )
// }

// function payloadFromForm(form) {
//   const payload = { title: form.title, description: form.description, status: form.status }
//   if (form.dueDate) payload.dueDate = new Date(form.dueDate).toISOString()
//   return payload
// }


//3


import React, { useEffect, useState } from 'react'
import api from '../api'
import './TaskList.css'

export default function TaskList({ view }) {
  const [tasks, setTasks] = useState([])
  const [form, setForm] = useState({ title: '', description: '', status: 'todo', dueDate: '' })
  const [editingId, setEditingId] = useState(null)
  const [error, setError] = useState('')

  const load = async () => {
    try {
      const { data } = await api.get('/tasks')
      setTasks(data.tasks)
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load tasks')
    }
  }

  useEffect(() => { load() }, [])

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    try {
      if (editingId) {
        const { data } = await api.put(`/tasks/${editingId}`, payloadFromForm(form))
        setTasks(tasks.map(t => t._id === editingId ? data.task : t))
        setEditingId(null)
      } else {
        const { data } = await api.post('/tasks', payloadFromForm(form))
        setTasks([data.task, ...tasks])
      }
      setForm({ title: '', description: '', status: 'todo', dueDate: '' })
    } catch (err) {
      setError(err.response?.data?.message || 'Save failed')
    }
  }

  const edit = (t) => {
    setEditingId(t._id)
    setForm({
      title: t.title,
      description: t.description || '',
      status: t.status,
      dueDate: t.dueDate ? new Date(t.dueDate).toISOString().slice(0, 10) : ''
    })
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const del = async (id) => {
    if (!window.confirm('Delete this task?')) return
    await api.delete(`/tasks/${id}`)
    setTasks(tasks.filter(t => t._id !== id))
  }

  return (
    <div className="task-container">
      {/* ✅ Show Add Task Form only in Home view */}
      {view === 'home' && (
        <>
          <h2 className="task-header">{editingId ? 'Edit Task' : 'New Task'}</h2>
          <form className="task-form" onSubmit={submit}>
            <input
              className="task-input"
              placeholder="Title"
              value={form.title}
              onChange={e => setForm({ ...form, title: e.target.value })}
              required
            />
            <textarea
              className="task-textarea"
              placeholder="Description"
              value={form.description}
              onChange={e => setForm({ ...form, description: e.target.value })}
            />
            <select
              className="task-select"
              value={form.status}
              onChange={e => setForm({ ...form, status: e.target.value })}
            >
              <option value="todo">To Do</option>
              <option value="in-progress">In Progress</option>
              <option value="done">Done</option>
            </select>
            <label className="task-label">
              Due date:
              <input
                className="task-date"
                type="date"
                value={form.dueDate}
                onChange={e => setForm({ ...form, dueDate: e.target.value })}
              />
            </label>
            <div className="task-btn-group">
              <button type="submit" className="btn btn-primary">
                {editingId ? 'Update' : 'Create'}
              </button>
              {editingId && (
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => {
                    setEditingId(null)
                    setForm({ title: '', description: '', status: 'todo', dueDate: '' })
                  }}
                >
                  Cancel
                </button>
              )}
            </div>
            {error && <p className="error-text">{error}</p>}
          </form>
        </>
      )}

      {/* ✅ Show only tasks in My Tasks view */}
      {view === 'tasks' && (
        <>
          <h3 className="task-header">Your Tasks</h3>
          {!tasks.length && <p className="empty-text">No tasks yet.</p>}
          <ul className="task-list">
            {tasks.map(t => (
              <li key={t._id} className="task-card">
                <div className="task-top">
                  <strong>{t.title}</strong>
                  <span className={`status-badge ${t.status}`}>{t.status}</span>
                </div>
                {t.description && <p>{t.description}</p>}
                {t.dueDate && <p>Due: {new Date(t.dueDate).toLocaleDateString()}</p>}
                <div className="task-actions">
                  <button className="btn btn-small btn-primary" onClick={() => edit(t)}>Edit</button>
                  <button className="btn btn-small btn-danger" onClick={() => del(t._id)}>Delete</button>
                </div>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  )
}

function payloadFromForm(form) {
  const payload = { title: form.title, description: form.description, status: form.status }
  if (form.dueDate) payload.dueDate = new Date(form.dueDate).toISOString()
  return payload
}






